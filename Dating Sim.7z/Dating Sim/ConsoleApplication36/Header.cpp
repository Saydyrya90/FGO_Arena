
//Functie ce incheie jocul si spune jucatorului daca a castigat
void game_end(int score)
{
	printf("\nYour final score is: %f \n", score);

	if (has_lamborghini == false)
	{
		if (has_girlfriend == false)
		{
			if (score < 0)
				printf("\nLooks like you lost, its okay. There is always another day.");
			else if (score > 0 && score <= 10)
				printf("\nMaybe you didn't get a girlfriend but you did pretty good! Your future looks bright!");
			else if (score > 15)
				printf("\nWho needs girls anyway?With your looks and personality you will rock the city!");
		}
		else if (has_girlfriend == true)
		{
			printf("\nGood job macho man!You we're made for this thing.\n");
			getch();
		}
	}

	else if (has_lamborghini = true)
	{
		if (has_girlfriend == false)
		{
			printf("\nMaybe you didn't get girlfriend\n");
			getch();
			printf("\nBut you have something more important\n");
			getch();
			printf("\nYour Lamborghini\n");
			getch();
			printf("\nYou are rich. Good job!\n");
		}
		else if (has_girlfriend == true)
		{
			printf("\nRich, good-looking and now you have a girlfriend too?\n");
			getch();
			printf("\nI'm proud of you\n");
		}
	}
	getch();

	printf("\nGAME OVER\n");
	getch();
	exit(0);
}


//Dialog tree,explicat in cealalta fila
void master_dialog(int x, int y)

{
	switch (index)
	{
	case 0:
		if (selection == 1)
		{
			score = score + 0.5;

			printf("\nYou: Hello\n");
			printf("Charlie: Hi");

			getch();
			printf("\nChoices: 1.What are you doing?  2.Do you like me? \n3.How is the weather in your town?  4.What do you think about biochemestry?\n");
			selection == 0;
			index = 1;
		}

		else if (selection == 2)
		{
			score = score + 0.5;
			selection == 0;
			index = 1;


			printf("\nYou: Good evening!\n");
			printf("Charlie: Helloo\n");


			getch();
			printf("\nChoices: 1.What are you doing?  2.Do you like me?  3.How is the weather in your town?  4.What do you think about biochemestry?\n");
		}

		else if (selection == 3)
		{
			score = score - 12;
			selection == 0;
			index = 2;

			printf("\nYou: I like to eat sunscreen :D \n");
			printf("Charlie: ...\n");

			getch();
			printf("\nChoices: 1.Why are you not replying?  2.Do you not like sunscreen?\n  3.When I was small I liked to eat chickens alive. They didn't like it...?\n");
		}

		break;


	case 1:
		if (selection == 1)
		{
			score = score + 0.1;
			selection == 0;
			index = 4;



			printf("\nYou: What are you doing?\n");
			printf("Charlie: Nothing much\n");

			getch();
			printf("\nChoices: 1.What does that mean?  2.Hmm I see...  3.*Wait for her to say something*\n");


		}

		else if (selection == 2)
		{
			score = score - 3;
			selection == 0;
			index = 7;


			printf("\nYou: Do you like me?\n");
			printf("Charlie: ...What?\n");


			getch();
			printf("\nChoices: 1.I asked you if you like me.  2.Forgive me, I am hungry and can't think straight.\n");
		}

		else if (selection == 3)
		{
			score = score + 0.4;
			selection == 0;
			index = 8;

			printf("\nYou: How is the weather in your town?\n");
			printf("Charlie: Its sunny\n");

			getch();
			printf("\nChoices: 1.Thats amazing!  2.I'm not sure about mine...lets go get a coffee and check it out together\n");
		}

		else if (selection == 4)
		{
			score = score + 1;
			selection == 0;
			index = 9;

			printf("\nYou: 4.What do you think about biochemestry?\n");
			printf("Charlie: I don't know. I was never interested in that.\n");

			getch();
			printf("\nChoices: 1.Perhaps you can recommend another subject?  2.Ok then...What do you think about death as a concept?\n");
		}

		break;


	case 2:
		if (selection == 1)
		{
			score = score - 7;
			selection == 0;
			index = 2;

			printf("\nYou: Why are you not replying?\n");
			printf("Charlie: ...");
			getch();
			printf("*Charlie unmatches you*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);


		}

		else if (selection == 2)
		{
			score = score - 5;
			selection == 0;
			index = 2;

			printf("\nYou: Do you not like sunscreen?\n");
			printf("Charlie: ...");
			getch();
			printf("*Charlie unmatches you*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);


		}

		else if (selection == 3)
		{
			score = score - 12;
			selection == 0;
			index = 2;

			printf("\nYou: When I was small I liked to eat chickens alive. They didn't like it :< \n");
			printf("Charlie: ...");
			getch();
			printf("Charlie: What is wrong with you?");
			getch();
			printf("Charlie: Your lamborghini is not even worth it.");
			getch();
			printf("Charlie: I should have stalked the other guy...");
			getch();
			printf("*Charlie unmatches you*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);
		}

		break;



	case 4:
		if (selection == 1)
		{
			score = score - 1;
			selection == 0;
			index = 6;

			printf("\nYou: What does that mean?\n");
			printf("Charlie: I'm just not doing anything right now.\n");

			getch();
			printf("\nChoices: 1.What does that mean?  2.Hmm I see... \n");


		}

		else if (selection == 2)
		{
			score = score - 2;
			selection == 0;
			index = 6;


			printf("\nYou: Hmm I see...\n");
			printf("Charlie: ...\n");


			getch();
		}

		else if (selection == 3)
		{
			score = score - 4;
			selection == 0;
			index = 4;

			printf("\nYou: *Waiting*\n");
			printf("Charlie: ... \n");
			getch();
			printf("*Charlie unmatches you*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);
		}

		break;

	case 6:
		if (selection == 1)
		{
			score = score - 1;
			selection == 0;
			index = 6;



			printf("\nYou: What does that mean?\n");
			printf("Charlie: I'm just not doing anything right now.\n");

			getch();
			printf("\nChoices: 1.What does that mean?  2.Hmm I see... \n");


		}

		else if (selection == 2)
		{
			score = score - 5;
			selection == 0;
			index = 6;


			printf("\nYou: Hmm I see...\n");
			printf("Charlie: ...\n");
			getch();
			printf("\nYou: ... \n");
			getch();
			printf("\nCharlie: ... \n");
			getch();
			printf("\n*Charlie unmatched you\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);

		}

		break;

	case 7:
		if (selection == 1)
		{

			selection == 0;

			printf("\nYou: I asked you if you like me.\n");
			printf("Charlie: ... \n");

			score = score - 4;

			getch();

			printf("\n*Charlie unmatched you\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);

		}

		else if (selection == 2)
		{
			score = score + 4;
			selection == 0;
			index = 10;


			printf("\nYou: Forgive me, I am hungry and can't  think straight.\n");
			printf("Charlie: Haha. Happens to me too\n");


			getch();
			printf("\nChoices: 1.Did you  know that I have a lamborghini?  2.How about we go eat something together so I can come to my senses?\n");
		}

		break;

	case 8:
		if (selection == 1)
		{
			score = score + 4;
			selection == 0;
			index = 11;

			printf("\nYou: Thats amazing!\n");
			printf("Charlie: I like your attitude :)) \n");

			getch();
			printf("\nChoices: 1. *you thank her and start a conversation about monkeys*  2.*you thank her and start a conversation about abortion rights in America*\n");

		}

		else if (selection == 2)
		{
			score = score + 6;
			selection == 0;
			index = 12;


			printf("\nYou: I'm not sure about mine...lets go get a coffee and check it out together.\n");
			printf("Charlie: Smooth. Okay then,when do you want to meet?\n");

			getch();
			printf("\nChoices: 1.My house, tommorow ;))  2.The new coffee shop downtown. You're from Generic City Name too right? \n");
		}

		break;


	case 9:
		if (selection == 1)
		{
			score = score + 2;
			selection == 0;
			index = 13;

			printf("\nYou: Perhaps you can recommend  another subject?\n");
			printf("Charlie: I like trains. \n");

			getch();
			printf("\nChoices: 1. OMG!I LOVE TRAINS TOO!  2. What? What is wrong with you?\n");

		}

		else if (selection == 2)
		{
			score = score + 6;
			selection == 0;
			index = 14;

			printf("\nYou: Ok then...What do you think about death as a concept?\n");
			printf("Charlie: I don't like it :/ \n");

			getch();
			printf("\nChoices: 1.Me neither...  2.But I do. Stay where you are, I'm comming to kill you.  \n");
		}

		break;

	case 10:
		if (selection == 1)
		{
			score = score + 100;
			selection == 0;
			index = 15;

			printf("\nYou: Did you know that I have a lamborghini?\n");
			printf("Charlie: Damn,why didn't you start like that? When are you picking me up?\n");

			getch();
			printf("\nChoices: 1. Right now  2. Right now\n");
		}

		else if (selection == 2)
		{
			score = score + 7;
			selection == 0;
			index = 16;

			printf("\nYou: How about we go eat something together so I can come to my senses?\n");
			printf("Charlie: Smooth. I'm free tommorow.\n");

			getch();
			printf("\nChoices: 1.Amazing! Lets meet at 4pm in the evening. 2.Actually I changed my mind, you are too ugly for me.  \n");
		}

		break;

	case 11:
		if (selection == 1)
		{
			score = score + 100;
			selection == 0;
			index = 17;

			printf("\nYou: *you thank her and start a conversation about monkeys*\n");
			printf("Charlie: Damn,why didn't you start like that? When are you picking me up?\n");

			getch();
			printf("\nChoices: 1. Right now  2. Right now\n");

		}

		else if (selection == 2)
		{
			score = score - 100;
			selection == 0;
			index = 11;

			printf("\nYou: *you thank her and start a conversation about abortion rights in America*\n");
			getch();
			printf("Charlie: *she gets very angry because you don't agree with her and unmatches you*\n");
			getch();
			printf("\n*Charlie unmatched you\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);

		}

		break;

	case 12:
		if (selection == 1)
		{
			score = score - 10;
			selection == 0;
			index = 12;

			printf("\nYou: My house, tommorow ;))\n");
			printf("Charlie: ... \n");
			getch();
			printf("\n*Charlie unmatched you\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);

		}

		else if (selection == 2)
		{
			score = score + 12;
			selection == 0;
			index = 12;


			printf("\nYou: The new coffee shop downton.You're from *Generic City name* too right?\n");
			getch();
			printf("Charlie: Yeah,I am! Here is my phone number: 0721685858\n");
			getch();
			printf("Charlie: We will talk about other details later.\n");
			getch();
			printf("*You go to the date with her and have a very good time together*");

			has_girlfriend = true;
			has_lamborghini = true;

			game_end(score);

		}

		break;

	case 13:
		if (selection == 1)
		{
			score = score + 25;
			selection == 0;
			index = 13;

			printf("\nYou: OMG! I LOVE TRAINS TOO!\n");
			printf("Charlie: :O \n");
			getch();
			printf("Charlie: I love you already <3 \n");
			getch();
			printf("*you go to dates with her and after 3 years marry her*\n");

			has_girlfriend = true;
			has_lamborghini = true;

			game_end(score);

		}

		else if (selection == 2)
		{
			score = score - 10;
			selection == 0;
			index = 13;


			printf("\nYou: What?What is wrong with you?\n");
			getch();
			printf("Charlie: ;-; \n");
			getch();
			printf("Charlie: You are mean... \n");
			getch();
			printf("\n*Charlie unmatched you\n");

			has_girlfriend = false;
			has_lamborghini = true;


			game_end(score);
		}

		break;

	case 14:
		if (selection == 1)
		{
			score = score - 3;
			selection == 0;
			index = 14;

			printf("\nYou: Me neither...\n");
			printf("Charlie: ... \n");

			getch();
			printf("*after 3 hours of waiting Charlie gets bored and unmatches you*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);

		}

		else if (selection == 2)
		{
			score = score + 7;
			selection == 0;
			index = 18;


			printf("\nYou: But I do. Stay where you are, I'm comming to kill you.\n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("Charlie: Hahahaahha\n");
			getch();
			printf("Charlie: That is the funniest thing I've heard all day. Want to meet for some coffee later? (: \n");

			getch();
			printf("\nChoices: 1. *accept the date and drink coffee with her* \n 2. *accept the date and actually go and kill her*\n");

		}

		break;

	case 15:
		if (selection == 1)
		{

			selection == 0;
			index = 15;
			score = score - 150;

			printf("\nYou: Right now  \n");
			getch();
			printf("*Charlie unmatches you for seemingly no reason*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);
		}

		else if (selection == 2)
		{
			score = score + 7;
			selection == 0;
			index = 15;


			printf("\nYou: Right now\n");
			getch();
			printf("*You meet with Charlie in a hotel and [DATA EXPUNGED]");

			has_girlfriend = true;
			has_lamborghini = true;

			game_end(score);
		}

		break;

	case 16:
		if (selection == 1)
		{
			score = score + 7;
			selection == 0;
			index = 20;

			printf("\nYou: Amazing! Lets meet at 4 in the evening.\n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("Charlie: Sure, seems great ^^ \n");
			getch();
			printf("Charlie: Sorry for the wait earlier, I was cleaning after my dog\n");
			getch();
			printf("*the next day you have a wonderfull date with Charlie*\n");

			has_girlfriend = true;
			has_lamborghini = true;

			game_end(score);
		}


		else if (selection == 2)
		{
			score = score - 12;
			selection == 0;
			index = 16;


			printf("\nYou: Actually I changed my mind, you are too ugly for me.\n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("Charlie: Really dude?Men...\n");
			getch();
			printf("*Charlie unmatches you*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);
		}

		break;

	case 17:
		if (selection == 1)
		{
			score = score + 8;
			selection == 0;
			index = 17;

			printf("\nYou: Right now  \n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("Charlie: Sorry, I was telling my friends about your amazing monkey facts. \n");
			getch();
			printf("*You go with Charlie to a ZOO date*\n");
			getch();
			printf("Basically,you just talk about animals for a few hours while eating ice cream with her.\n");
			getch();
			printf("I don't even know why I'm explaining you this but yeah.\n");

			has_girlfriend = true;
			has_lamborghini = true;

			game_end(score);
		}

		else if (selection == 2)
		{
			score = score + 6;
			selection == 0;
			index = 21;

			printf("\nYou: Right now\n");
			getch();
			printf("*You rob a bank with Charlie dressed in monkey suits*\n");
			getch();
			printf("*You and Charlie are each holding a hostage*");
			getch();
			printf("\nChoices: 1. *kill the hostage you are holding to show the police you are serious about this. \n 2. *try to shoot a police officer*\n");

		}

		break;

	case 18:
		if (selection == 1)
		{
			score = score - 10;
			selection == 0;
			index = 18;

			printf("\nYou: *accept the date and go drink coffee with her*\n");
			getch();
			printf("\n*You and Charlie are in the coffee shop at a table near the front windows*\n");
			getch();
			printf("\n*She looks at you rather strange...*\n");
			getch();
			printf("\n*She suddenly stops talking...*\n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("You: Are you feeling okay Charlie?\n");
			getch();
			printf("Charlie: I... \n");
			getch();
			printf("You: Is there something wrong?\n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("Wha...\n");
			getch();
			printf("*Charlie puts a finger to your lips to silence you*\n");
			getch();
			printf("Charlie: Im sorry.\n");
			getch();
			printf("*Charlie stabs you in the heart with a hunting knife*\n");
			getch();
			printf("*You are losing blood very fast*\n");
			getch();
			printf("You:Chagh..\n");
			getch();
			printf("*Charlie steals the keys of your lamborghini from your pocket*\n");
			getch();
			printf("You: WHy?\n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("*She doesn't say a thing*\n");
			getch();
			printf("*She looks you in the eyes as you draw your final breath*\n");
			getch();
			printf("*Charlie: Goodbye\n");
			getch();

			has_girlfriend = false;
			has_lamborghini = false;

			game_end(score);
		}

		else if (selection == 2)
		{
			score = score + 12;
			selection == 0;
			index = 19;


			printf("\n*accept the date and actually go and kill her*\n");
			getch();
			printf("\n*You enter the coffee shop but it seems nobody is inside*\n");
			getch();
			printf("\n*You see somebody behind you with the corner of your left eye*\n");

			getch();
			printf("\nChoices: 1. *duck down* \n 2. *turn around to ask the person about the empty shop*\n");

		}

		break;

	case 19:
		if (selection == 1)
		{
			score = score + 6;
			selection == 0;
			index = 22;

			printf("\n*You duck down and dodge the knife*\n");
			getch();
			printf("\n*You roll forward and turn back to see who attacked you*\n");
			getch();
			printf("\nYou:...\n");
			getch();
			printf("\nYou: Charlie!?\n");
			getch();
			printf("\n*Charlie stares you in the eyes*\n");
			getch();
			printf("\nCharlie: Only one of us will leave this place alive.\n");
			getch();
			printf("\nYou: What are you talking about?\n");
			getch();
			printf("\nYou: What is wrong with you?\n");
			getch();
			printf("\nCharlie: Die\n");
			getch();
			printf("\n*Charlie  starts  running towards you  with the knife*\n");
			getch();
			printf("\n*You grab a chair from the table on the left*\n");

			getch();
			printf("\nChoices: 1. *throw the chair at her and try to run for the exit* \n 2. *block her knife with the chair*\n");

		}

		else if (selection == 2)
		{
			score = score - 10;
			selection == 0;
			index = 19;

			printf("\n*you turn around to greet the new friend :D*\n");
			getch();
			printf("\n*You see Charlie*\n");
			getch();
			printf("\n*She quickly puts something back in her bag*\n");
			getch();
			printf("\nYou: Hey Charlie, how is your day going? ^^\n");
			getch();
			printf("\nCharlie:...\n");
			getch();
			printf("\n*She is staring right through you*\n");
			getch();
			printf("\nYou: Hey,are you okay?\n");
			getch();
			printf("\n*Charlie quickly snaps out of it*\n");
			getch();
			printf("\nCharlie: Yeah,I am fine. Just tired a bit.\n");
			getch();
			printf("\n*You both sit at a table near the windows and start chatting about monkeys*\n");
			getch();
			printf("\nYou:So,why were you distracted earlier?\n");
			getch();
			printf("\nCharlie:Distracted? I don't know what you mean ^^ \n");
			getch();
			printf("\nYou:Well,you looked pretty angry when you first arrived.\n");
			getch();
			printf("\nCharlie:Oh, that? Haha, it will be nothing\n");
			getch();
			printf("\nYou:Don't you mean...was?\n");
			getch();
			printf("\nCharlie:...\n");
			getch();
			printf("\nYou:Charlie?\n");
			getch();
			printf("\n*She quickly pulls out the hunting knife out of the bag and stabs you*\n");
			getch();
			printf("\n*You bleed out for a few minutes and eventually die*\n");
			getch();

			has_girlfriend = false;
			has_lamborghini = false;

			game_end(score);
		}

		break;

	case 22:
		if (selection == 1)
		{
			score = score - 10;
			selection == 0;
			index = 22;

			printf("\n *you throw the chair at her and try to run for the exit behind her*\n");
			getch();
			printf("\n*She gets stunned for one second but stabs you in the back while trying to get past her*\n");
			getch();
			printf("\nYou:Oh my go...\n");
			getch();
			printf("\n*She stabs you until you die*\n");
			getch();

			has_girlfriend = false;
			has_lamborghini = false;

			game_end(score);

		}

		else if (selection == 2)
		{
			score = score + 7;
			selection == 0;
			index = 23;
			printf("\n *you hold her back with the chair*\n");
			getch();
			printf("\nYou:Why are you doing this??\n");
			getch();
			printf("\nCharlie:...\n");
			getch();
			printf("\n*Charlie tries to get closer to you*\n");

			getch();
			printf("\nChoices: 1. *hit her with the chair* \n 2. *continue to hold her with the chair*\n");
		}

		break;

	case 23:
		if (selection == 1)
		{
			score = score + 4;
			selection == 0;
			index = 24;

			printf("\n *you hit her with the chair*\n");
			getch();
			printf("\n*She falls to the ground and drops her knife*\n");

			getch();
			printf("\nChoices: 1. *rush to take her knife* \n 2. *run for the exit*\n");
		}

		else if (selection == 2)
		{
			score = score - 5;
			selection == 0;
			index = 23;


			printf("\n *you continue to hold her with the chair*\n");
			getch();
			printf("\nCharlie: Enough of this!\n");
			getch();
			printf("\n*Charlie cuts 3 of your fingers you're using to hold your chair*\n");
			getch();
			printf("\nYou:ARGH!\n");
			getch();
			printf("\n*The chair slips from your left palm*\n");
			getch();
			printf("\nCharlie:You're mine!\n");
			getch();
			printf("\n*Charlie throws you on the ground with a kick*\n");
			getch();
			printf("\n*Charlie stabs you until you die*\n");
			getch();

			has_girlfriend = false;
			has_lamborghini = false;

			game_end(score);

		}

		break;

	case 24:
		if (selection == 1)
		{
			score = score - 6;
			selection == 0;
			index = 24;

			printf("\n *you rush to take her knife*\n");
			getch();
			printf("\n*you take her knife*\n");
			getch();

			printf("\n*She explodes and kills both of you*\n");
			getch();

			has_girlfriend = false;
			has_lamborghini = false;

			game_end(score);

		}

		else if (selection == 2)
		{
			score = score + 15;
			selection == 0;
			index = 24;

			printf("\n*You run for the exit*\n");
			getch();
			printf("\n*You escape and call the police*\n");
			getch();
			printf("\n*The police arrives and arrests Charlie*\n");
			getch();
			printf("\n*You drive your lamborghini in the sunset and enjoy your free coffee*\n");
			getch();

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);

		}

		break;

	case 21:
		if (selection == 1)
		{
			score = score - 5;
			selection == 0;
			index = 21;

			printf("\n*you kill the hostage you are holding*\n");
			getch();
			printf("\n*the police shoots both you and Charlie*\n");
			getch();
			printf("\n*both of you get arrested*\n");
			getch();
			printf("\n*you drop the soap in prison*\n");
			getch();

			has_girlfriend = true;
			has_lamborghini = true;

			game_end(score);
		}

		else if (selection == 2)
		{
			score = score + 5;
			selection == 0;
			index = 21;

			printf("\n*you try to shoot a police officer*\n");
			getch();
			printf("*the sniper outside takes advantage of you taking your aim away from the hostage and shoots your hand*\n");
			getch();
			printf("*Charlie's left hand gets shot too and she drops her pistol*");
			getch();
			printf("\n*both of you get arrested*\n");

			has_girlfriend = true;
			has_lamborghini = false;

			game_end(score);
		}

	default:
		printf("\nPlease pick one of the options above.\n");
		getch();

	}
}
