#pragma once
#ifdef HEADER_H
extern bool has_lamborghini;
extern bool has_girlfriend;
extern int index;
extern int selection;
extern float score;
void game_end(int a);
void master_dialog(int x, int y);
#endif