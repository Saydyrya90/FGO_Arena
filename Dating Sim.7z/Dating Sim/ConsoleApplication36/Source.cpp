﻿#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
/*
#include "C:\Users\saydy\Desktop\master_dialog.txt"
Note:Am incercat sa folosesc un document txt in care sa stochez functiile dar locatia nu este relativa si deci aplicatia nu ar merge in calculatorul altcuiva
deoarece locatia difera. 
*/

//setup variabile
int win_checker, lost_checker,continue_checker,index,selection;
int eye_colour_check;
float score;
char play_or_quit;
bool has_girlfriend = false, has_lamborghini = false,is_playing = true;
void game_end(int a);
void master_dialog(int x, int y);

void main()
{
	printf("\nWelcome to \"Love for Costy\"!\nThis is a text-based online dating sim game made to teach nerds like you how to talk to girls.\n\nRules:\nUsing the keys {1,2,3,4} you have to select one of the answers given to you by the game.\nEvery answer gives/takes away a certain ammount of points.\nYou win the game by ammounting a lot of points or if you manage to make a girl like you.\nYou can lose if your answer is too bad.\nWhen you start the game you make a profile.Some physical/personality traits give you more points at the beginning.This can save you from bad dialogue choices down the road.\n");
	printf("\n\nAre you ready to play?[y/n]\n");

	//Decizi daca vrei sa joci sau sa il inchizi. Am folosit goto-ul in  loc de un loop cu while.
continue_checker_jump:
	{
		scanf("%c", &play_or_quit);
	}

	switch (play_or_quit)
	{
	case 'y':
		break;

	case 'n':
		exit(0);
		break;

	default:
		printf("\nPlease press only [y] or [n]\n");
		play_or_quit = 0;
		goto continue_checker_jump;
	}


	printf("\nLets continue then.\nPlease make a profile\n");

	struct Profile
	{
		int age;
		int height;
		int weight_kg;
		char eye_colour[20];
	}Costel;

	getch();
	//Decide cate puncte sa iti ofere in functie de varsta.
	printf("\n\nHow old are you?\n");
	scanf("%d", &Costel.age);


	if (Costel.age < 18) {
		score = score - 3;
		printf("\nAren't you a little too young for this?\n");
	}
	else if (Costel.age >= 18 && Costel.age <= 30)
	{
		score = score + 5;
		printf("\nMrr\n");
	}
	else if (Costel.age > 30 && Costel.age <= 40)
	{
		score = score + 2.5;
		printf("\nA bit too old for this but ok.\n");
	}
	else if (Costel.age > 40)
	{
		score = score - 4;
		printf("\nToo old but okay...\n");
	}

	getch();

	//Ofera puncte in functie de inaltime
	printf("\nHow tall are you(cm)?\n");
	scanf("%d", &Costel.height);


	if (Costel.height <= 150) {
		score = score - 4;
		printf("\nHello there Mr.Dwarf\n");
	}

	else if (Costel.height > 150 && Costel.height <= 165)
	{
		score = score - 3;
		printf("\nKinda short  but maybe you are rich.\n");
	}

	else if (Costel.height > 165 && Costel.height <= 175)
	{
		score = score + 2;
		printf("\nA bit too short but maybe you are very cute.\n");
		getch();
		if (Costel.age > 40)
			printf(" *looks at age* \nActually...nevermind what I said.\n");
	}
	else if (Costel.height > 175 && Costel.height <= 180)
	{
		score = score + 4;
		printf("\nHello there cute guy.\n");
	}

	else if (Costel.height > 180 && Costel.height <= 190)
	{
		score = score + 5;
		printf("\nHello there mr.Perfect.\n");
	}

	else if (Costel.height > 190 && Costel.height <= 200)
	{
		score = score + 2.5;
		printf("\nYou are very tall...\n");
	}

	else if (Costel.height > 200)
	{
		score = score - 2;
		printf("\nWhat do you eat my friend??\n");
	}

	getch();

	//Decide puncte oferite in functie de greutate
	printf("\nHow much do you weight(kg)?\n");
	scanf("%d", &Costel.weight_kg);


	if (Costel.weight_kg <= 45)
	{
		score = score - 2.5;
		printf("\nYou are a kid aren't you?\n");
		if (Costel.age < 18)
		{
			getch();
			score = score - 1;
			printf("\nYeah...I knew it.\n");
		}
	}

	else if (Costel.weight_kg > 45 && Costel.weight_kg <= 55)
	{
		score = score - 2;
		printf("\nYou look like you need a BigMac.\n");
	}

	else if (Costel.weight_kg > 55 && Costel.weight_kg <= 60)
	{
		score = score - 1;
		printf("\nYou are a couple of meals away from being normal.\n");
	}

	else if (Costel.weight_kg > 60 && Costel.weight_kg <= 70)
	{
		printf("\nA normal person, WAW.\n");
		score = score + 3;
	}

	else if (Costel.weight_kg > 70 && Costel.weight_kg <= 85)
	{
		score = score + 5.5;
		printf("\nNice muscles you got there\n");
	}

	else if (Costel.weight_kg > 85)
	{
		score = score - 6;
		printf("\nYou need exercise\n");
	}
	getch();

	//Decide puncte oferite in functie de culoarea ochilor
	printf("\nWhat is your eye color?");
	printf("\n1.Blue?  2.Green?  3.Brown?  4.White?  5.Purple?  6.Other?\n");

	//Am folosit un jump in loc de loop (in cazul in care cineva nu stie sa apese pe numere de la 1 la 6).
eye_colour_check_jump:
	{
		scanf("%d", &eye_colour_check);
	}

	switch (eye_colour_check)
	{
	case 1:
		score = score + 3;
		break;
	case 2:
		score = score + 2;
		break;
	case 3:
		score = score + 1.5;
		break;
	case 4:
		score = score - 2;
		printf("\nZici ca esti mort\n");
		getch();
		break;
	case 5:
		score = score - 4;
		printf("\nWeeb.\n");
		getch();
		break;
	case 6:
		score = score - 5;
		printf("\n...");
		getch();
		printf("\nI don't even want to know.\n");
		getch();
		break;
	default:
		printf("\nPlease pick one of the 6 options.\n");
		getch();
		eye_colour_check = NULL;
		goto eye_colour_check_jump;
	}

	//Arata scor inainte sa inceapa dialog tree-ul
	printf("\nYour score is: %f \n", score);
	getch();

	//ofera complimente, pentru ca toti avem nevoie de asta
	if (score > 0 && score <= 3)
		printf("\nYou are doing ok so far. Maybe you actually have a chance.\n");
	else if (score > 3 && score <= 10)
		printf("\nSomebody is doing pretty good.Go get them tiger!\n");
	else if (score > 10)
		printf("\nWell you sure are doing great. This will be a walk in the park for you.\n");

	else if (score > -5 && score < 0)
		printf("\nDear God you are not doing fine...maybe you compensate with your personality.\n");
	else if (score < -5)
		printf("\nOh...good luck dude.You'll need it...\n");

	getch();
	printf("\nWell then.Lets begin!\n\n\n\n");

	//Intrebare initiala
	printf("Say hello to Charlie,your match.\nFirst dialogue options are: \n 1.Hello   2.Good evening!   3.I like to eat sunscreen :D");




	/*
	Note: Desi am folosit un bool pentru is_playing tin sa mentionez ca  nu o sa fie niciodata fals.
	Folosesc functia  game_end ca sa inchei jocul in functie de puncte si deciziile luate.
	Index e folosit pentru a determina ce decizie a luat jucatorul.
	Selection e folosit pentru a determina ce decizie o sa ia jucatorul.
	Selection e ales manual iar index e automat si cel de-al doilea calatoreste singur prin alte index-uri din switch folosind variabila "selection".
	Pentru game loop doar am  chemat functia care se ocupa de index-uri de fiecare data cand introduceam un "selection" nou.
	Note extra: Initial am vrut sa ofer jucatorului mai multe persoane cu care sa vorbeasca.
	Dar m-am razgandit si am folosit doar o persoana, Charlie , pentru a face jucatorul sa vrea sa repete experienta pentru a "cunoaste persoana mai bine".
	*/

	//Game loop
	while (is_playing = true)
	{
		if (index >= 0)
		{
			printf("\n\nChoose: \n");
			scanf("%d", &selection);
			master_dialog(index, selection);
		}

	}

}

//Functie ce incheie jocul si spune jucatorului daca a castigat
void game_end(int score)
{
	printf("\nYour final score is: %f \n", score);

	if (has_lamborghini == false)
	{
		if (has_girlfriend == false)
		{
			if (score < 0)
				printf("\nLooks like you lost, its okay. There is always another day.");
			else if (score > 0 && score <= 10)
				printf("\nMaybe you didn't get a girlfriend but you did pretty good! Your future looks bright!");
			else if (score > 15)
				printf("\nWho needs girls anyway?With your looks and personality you will rock the city!");
		}
		else if (has_girlfriend == true)
		{
			printf("\nGood job macho man!You we're made for this thing.\n");
			getch();
		}
	}

	else if (has_lamborghini = true)
	{
		if (has_girlfriend == false)
		{
			printf("\nMaybe you didn't get girlfriend\n");
			getch();
			printf("\nBut you have something more important\n");
			getch();
			printf("\nYour Lamborghini\n");
			getch();
			printf("\nYou are rich. Good job!\n");
		}
		else if (has_girlfriend == true)
		{
			printf("\nRich, good-looking and now you have a girlfriend too?\n");
			getch();
			printf("\nI'm proud of you\n");
		}
	}
	getch();

	printf("\nGAME OVER\n");
	getch();
	exit(0);
}


//Dialog tree,explicat in cealalta fila
void master_dialog(int x, int y)

{
	switch (index)
	{
	case 0:
		if (selection == 1)
		{
			score = score + 0.5;

			printf("\nYou: Hello\n");
			printf("Charlie: Hi");

			getch();
			printf("\nChoices: 1.What are you doing?  2.Do you like me? \n3.How is the weather in your town?  4.What do you think about biochemestry?\n");
			selection == 0;
			index = 1;
		}

		else if (selection == 2)
		{
			score = score + 0.5;
			selection == 0;
			index = 1;


			printf("\nYou: Good evening!\n");
			printf("Charlie: Helloo\n");


			getch();
			printf("\nChoices: 1.What are you doing?  2.Do you like me?  3.How is the weather in your town?  4.What do you think about biochemestry?\n");
		}

		else if (selection == 3)
		{
			score = score - 12;
			selection == 0;
			index = 2;

			printf("\nYou: I like to eat sunscreen :D \n");
			printf("Charlie: ...\n");

			getch();
			printf("\nChoices: 1.Why are you not replying?  2.Do you not like sunscreen?\n  3.When I was small I liked to eat chickens alive. They didn't like it...?\n");
		}

		break;


	case 1:
		if (selection == 1)
		{
			score = score + 0.1;
			selection == 0;
			index = 4;



			printf("\nYou: What are you doing?\n");
			printf("Charlie: Nothing much\n");

			getch();
			printf("\nChoices: 1.What does that mean?  2.Hmm I see...  3.*Wait for her to say something*\n");


		}

		else if (selection == 2)
		{
			score = score - 3;
			selection == 0;
			index = 7;


			printf("\nYou: Do you like me?\n");
			printf("Charlie: ...What?\n");


			getch();
			printf("\nChoices: 1.I asked you if you like me.  2.Forgive me, I am hungry and can't think straight.\n");
		}

		else if (selection == 3)
		{
			score = score + 0.4;
			selection == 0;
			index = 8;

			printf("\nYou: How is the weather in your town?\n");
			printf("Charlie: Its sunny\n");

			getch();
			printf("\nChoices: 1.Thats amazing!  2.I'm not sure about mine...lets go get a coffee and check it out together\n");
		}

		else if (selection == 4)
		{
			score = score + 1;
			selection == 0;
			index = 9;

			printf("\nYou: 4.What do you think about biochemestry?\n");
			printf("Charlie: I don't know. I was never interested in that.\n");

			getch();
			printf("\nChoices: 1.Perhaps you can recommend another subject?  2.Ok then...What do you think about death as a concept?\n");
		}

		break;


	case 2:
		if (selection == 1)
		{
			score = score - 7;
			selection == 0;
			index = 2;

			printf("\nYou: Why are you not replying?\n");
			printf("Charlie: ...");
			getch();
			printf("*Charlie unmatches you*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);


		}

		else if (selection == 2)
		{
			score = score - 5;
			selection == 0;
			index = 2;

			printf("\nYou: Do you not like sunscreen?\n");
			printf("Charlie: ...");
			getch();
			printf("*Charlie unmatches you*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);


		}

		else if (selection == 3)
		{
			score = score - 12;
			selection == 0;
			index = 2;

			printf("\nYou: When I was small I liked to eat chickens alive. They didn't like it :< \n");
			printf("Charlie: ...");
			getch();
			printf("Charlie: What is wrong with you?");
			getch();
			printf("Charlie: Your lamborghini is not even worth it.");
			getch();
			printf("Charlie: I should have stalked the other guy...");
			getch();
			printf("*Charlie unmatches you*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);
		}

		break;



	case 4:
		if (selection == 1)
		{
			score = score - 1;
			selection == 0;
			index = 6;

			printf("\nYou: What does that mean?\n");
			printf("Charlie: I'm just not doing anything right now.\n");

			getch();
			printf("\nChoices: 1.What does that mean?  2.Hmm I see... \n");


		}

		else if (selection == 2)
		{
			score = score - 2;
			selection == 0;
			index = 6;


			printf("\nYou: Hmm I see...\n");
			printf("Charlie: ...\n");


			getch();
		}

		else if (selection == 3)
		{
			score = score - 4;
			selection == 0;
			index = 4;

			printf("\nYou: *Waiting*\n");
			printf("Charlie: ... \n");
			getch();
			printf("*Charlie unmatches you*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);
		}

		break;

	case 6:
		if (selection == 1)
		{
			score = score - 1;
			selection == 0;
			index = 6;



			printf("\nYou: What does that mean?\n");
			printf("Charlie: I'm just not doing anything right now.\n");

			getch();
			printf("\nChoices: 1.What does that mean?  2.Hmm I see... \n");


		}

		else if (selection == 2)
		{
			score = score - 5;
			selection == 0;
			index = 6;


			printf("\nYou: Hmm I see...\n");
			printf("Charlie: ...\n");
			getch();
			printf("\nYou: ... \n");
			getch();
			printf("\nCharlie: ... \n");
			getch();
			printf("\n*Charlie unmatched you\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);

		}

		break;

	case 7:
		if (selection == 1)
		{

			selection == 0;

			printf("\nYou: I asked you if you like me.\n");
			printf("Charlie: ... \n");

			score = score - 4;

			getch();

			printf("\n*Charlie unmatched you\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);

		}

		else if (selection == 2)
		{
			score = score + 4;
			selection == 0;
			index = 10;


			printf("\nYou: Forgive me, I am hungry and can't  think straight.\n");
			printf("Charlie: Haha. Happens to me too\n");


			getch();
			printf("\nChoices: 1.Did you  know that I have a lamborghini?  2.How about we go eat something together so I can come to my senses?\n");
		}

		break;

	case 8:
		if (selection == 1)
		{
			score = score + 4;
			selection == 0;
			index = 11;

			printf("\nYou: Thats amazing!\n");
			printf("Charlie: I like your attitude :)) \n");

			getch();
			printf("\nChoices: 1. *you thank her and start a conversation about monkeys*  2.*you thank her and start a conversation about abortion rights in America*\n");

		}

		else if (selection == 2)
		{
			score = score + 6;
			selection == 0;
			index = 12;


			printf("\nYou: I'm not sure about mine...lets go get a coffee and check it out together.\n");
			printf("Charlie: Smooth. Okay then,when do you want to meet?\n");

			getch();
			printf("\nChoices: 1.My house, tommorow ;))  2.The new coffee shop downtown. You're from Generic City Name too right? \n");
		}

		break;


	case 9:
		if (selection == 1)
		{
			score = score + 2;
			selection == 0;
			index = 13;

			printf("\nYou: Perhaps you can recommend  another subject?\n");
			printf("Charlie: I like trains. \n");

			getch();
			printf("\nChoices: 1. OMG!I LOVE TRAINS TOO!  2. What? What is wrong with you?\n");

		}

		else if (selection == 2)
		{
			score = score + 6;
			selection == 0;
			index = 14;

			printf("\nYou: Ok then...What do you think about death as a concept?\n");
			printf("Charlie: I don't like it :/ \n");

			getch();
			printf("\nChoices: 1.Me neither...  2.But I do. Stay where you are, I'm comming to kill you.  \n");
		}

		break;

	case 10:
		if (selection == 1)
		{
			score = score + 100;
			selection == 0;
			index = 15;

			printf("\nYou: Did you know that I have a lamborghini?\n");
			printf("Charlie: Damn,why didn't you start like that? When are you picking me up?\n");

			getch();
			printf("\nChoices: 1. Right now  2. Right now\n");
		}

		else if (selection == 2)
		{
			score = score + 7;
			selection == 0;
			index = 16;

			printf("\nYou: How about we go eat something together so I can come to my senses?\n");
			printf("Charlie: Smooth. I'm free tommorow.\n");

			getch();
			printf("\nChoices: 1.Amazing! Lets meet at 4pm in the evening. 2.Actually I changed my mind, you are too ugly for me.  \n");
		}

		break;

	case 11:
		if (selection == 1)
		{
			score = score + 100;
			selection == 0;
			index = 17;

			printf("\nYou: *you thank her and start a conversation about monkeys*\n");
			printf("Charlie: Damn,why didn't you start like that? When are you picking me up?\n");

			getch();
			printf("\nChoices: 1. Right now  2. Right now\n");

		}

		else if (selection == 2)
		{
			score = score - 100;
			selection == 0;
			index = 11;

			printf("\nYou: *you thank her and start a conversation about abortion rights in America*\n");
			getch();
			printf("Charlie: *she gets very angry because you don't agree with her and unmatches you*\n");
			getch();
			printf("\n*Charlie unmatched you\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);

		}

		break;

	case 12:
		if (selection == 1)
		{
			score = score - 10;
			selection == 0;
			index = 12;

			printf("\nYou: My house, tommorow ;))\n");
			printf("Charlie: ... \n");
			getch();
			printf("\n*Charlie unmatched you\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);

		}

		else if (selection == 2)
		{
			score = score + 12;
			selection == 0;
			index = 12;


			printf("\nYou: The new coffee shop downton.You're from *Generic City name* too right?\n");
			getch();
			printf("Charlie: Yeah,I am! Here is my phone number: 0721685858\n");
			getch();
			printf("Charlie: We will talk about other details later.\n");
			getch();
			printf("*You go to the date with her and have a very good time together*");

			has_girlfriend = true;
			has_lamborghini = true;

			game_end(score);

		}

		break;

	case 13:
		if (selection == 1)
		{
			score = score + 25;
			selection == 0;
			index = 13;

			printf("\nYou: OMG! I LOVE TRAINS TOO!\n");
			printf("Charlie: :O \n");
			getch();
			printf("Charlie: I love you already <3 \n");
			getch();
			printf("*you go to dates with her and after 3 years marry her*\n");

			has_girlfriend = true;
			has_lamborghini = true;

			game_end(score);

		}

		else if (selection == 2)
		{
			score = score - 10;
			selection == 0;
			index = 13;


			printf("\nYou: What?What is wrong with you?\n");
			getch();
			printf("Charlie: ;-; \n");
			getch();
			printf("Charlie: You are mean... \n");
			getch();
			printf("\n*Charlie unmatched you\n");

			has_girlfriend = false;
			has_lamborghini = true;


			game_end(score);
		}

		break;

	case 14:
		if (selection == 1)
		{
			score = score - 3;
			selection == 0;
			index = 14;

			printf("\nYou: Me neither...\n");
			printf("Charlie: ... \n");

			getch();
			printf("*after 3 hours of waiting Charlie gets bored and unmatches you*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);

		}

		else if (selection == 2)
		{
			score = score + 7;
			selection == 0;
			index = 18;


			printf("\nYou: But I do. Stay where you are, I'm comming to kill you.\n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("Charlie: Hahahaahha\n");
			getch();
			printf("Charlie: That is the funniest thing I've heard all day. Want to meet for some coffee later? (: \n");

			getch();
			printf("\nChoices: 1. *accept the date and drink coffee with her* \n 2. *accept the date and actually go and kill her*\n");

		}

		break;

	case 15:
		if (selection == 1)
		{

			selection == 0;
			index = 15;
			score = score - 150;

			printf("\nYou: Right now  \n");
			getch();
			printf("*Charlie unmatches you for seemingly no reason*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);
		}

		else if (selection == 2)
		{
			score = score + 7;
			selection == 0;
			index = 15;


			printf("\nYou: Right now\n");
			getch();
			printf("*You meet with Charlie in a hotel and [DATA EXPUNGED]");

			has_girlfriend = true;
			has_lamborghini = true;

			game_end(score);
		}

		break;

	case 16:
		if (selection == 1)
		{
			score = score + 7;
			selection == 0;
			index = 20;

			printf("\nYou: Amazing! Lets meet at 4 in the evening.\n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("Charlie: Sure, seems great ^^ \n");
			getch();
			printf("Charlie: Sorry for the wait earlier, I was cleaning after my dog\n");
			getch();
			printf("*the next day you have a wonderfull date with Charlie*\n");

			has_girlfriend = true;
			has_lamborghini = true;

			game_end(score);
		}


		else if (selection == 2)
		{
			score = score - 12;
			selection == 0;
			index = 16;


			printf("\nYou: Actually I changed my mind, you are too ugly for me.\n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("Charlie: Really dude?Men...\n");
			getch();
			printf("*Charlie unmatches you*\n");

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);
		}

		break;

	case 17:
		if (selection == 1)
		{
			score = score + 8;
			selection == 0;
			index = 17;

			printf("\nYou: Right now  \n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("Charlie: Sorry, I was telling my friends about your amazing monkey facts. \n");
			getch();
			printf("*You go with Charlie to a ZOO date*\n");
			getch();
			printf("Basically,you just talk about animals for a few hours while eating ice cream with her.\n");
			getch();
			printf("I don't even know why I'm explaining you this but yeah.\n");

			has_girlfriend = true;
			has_lamborghini = true;

			game_end(score);
		}

		else if (selection == 2)
		{
			score = score + 6;
			selection == 0;
			index = 21;

			printf("\nYou: Right now\n");
			getch();
			printf("*You rob a bank with Charlie dressed in monkey suits*\n");
			getch();
			printf("*You and Charlie are each holding a hostage*");
			getch();
			printf("\nChoices: 1. *kill the hostage you are holding to show the police you are serious about this. \n 2. *try to shoot a police officer*\n");

		}

		break;

	case 18:
		if (selection == 1)
		{
			score = score - 10;
			selection == 0;
			index = 18;

			printf("\nYou: *accept the date and go drink coffee with her*\n");
			getch();
			printf("\n*You and Charlie are in the coffee shop at a table near the front windows*\n");
			getch();
			printf("\n*She looks at you rather strange...*\n");
			getch();
			printf("\n*She suddenly stops talking...*\n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("You: Are you feeling okay Charlie?\n");
			getch();
			printf("Charlie: I... \n");
			getch();
			printf("You: Is there something wrong?\n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("Wha...\n");
			getch();
			printf("*Charlie puts a finger to your lips to silence you*\n");
			getch();
			printf("Charlie: Im sorry.\n");
			getch();
			printf("*Charlie stabs you in the heart with a hunting knife*\n");
			getch();
			printf("*You are losing blood very fast*\n");
			getch();
			printf("You:Chagh..\n");
			getch();
			printf("*Charlie steals the keys of your lamborghini from your pocket*\n");
			getch();
			printf("You: WHy?\n");
			getch();
			printf("Charlie: ... \n");
			getch();
			printf("*She doesn't say a thing*\n");
			getch();
			printf("*She looks you in the eyes as you draw your final breath*\n");
			getch();
			printf("*Charlie: Goodbye\n");
			getch();

			has_girlfriend = false;
			has_lamborghini = false;

			game_end(score);
		}

		else if (selection == 2)
		{
			score = score + 12;
			selection == 0;
			index = 19;


			printf("\n*accept the date and actually go and kill her*\n");
			getch();
			printf("\n*You enter the coffee shop but it seems nobody is inside*\n");
			getch();
			printf("\n*You see somebody behind you with the corner of your left eye*\n");

			getch();
			printf("\nChoices: 1. *duck down* \n 2. *turn around to ask the person about the empty shop*\n");

		}

		break;

	case 19:
		if (selection == 1)
		{
			score = score + 6;
			selection == 0;
			index = 22;

			printf("\n*You duck down and dodge the knife*\n");
			getch();
			printf("\n*You roll forward and turn back to see who attacked you*\n");
			getch();
			printf("\nYou:...\n");
			getch();
			printf("\nYou: Charlie!?\n");
			getch();
			printf("\n*Charlie stares you in the eyes*\n");
			getch();
			printf("\nCharlie: Only one of us will leave this place alive.\n");
			getch();
			printf("\nYou: What are you talking about?\n");
			getch();
			printf("\nYou: What is wrong with you?\n");
			getch();
			printf("\nCharlie: Die\n");
			getch();
			printf("\n*Charlie  starts  running towards you  with the knife*\n");
			getch();
			printf("\n*You grab a chair from the table on the left*\n");

			getch();
			printf("\nChoices: 1. *throw the chair at her and try to run for the exit* \n 2. *block her knife with the chair*\n");

		}

		else if (selection == 2)
		{
			score = score - 10;
			selection == 0;
			index = 19;

			printf("\n*you turn around to greet the new friend :D*\n");
			getch();
			printf("\n*You see Charlie*\n");
			getch();
			printf("\n*She quickly puts something back in her bag*\n");
			getch();
			printf("\nYou: Hey Charlie, how is your day going? ^^\n");
			getch();
			printf("\nCharlie:...\n");
			getch();
			printf("\n*She is staring right through you*\n");
			getch();
			printf("\nYou: Hey,are you okay?\n");
			getch();
			printf("\n*Charlie quickly snaps out of it*\n");
			getch();
			printf("\nCharlie: Yeah,I am fine. Just tired a bit.\n");
			getch();
			printf("\n*You both sit at a table near the windows and start chatting about monkeys*\n");
			getch();
			printf("\nYou:So,why were you distracted earlier?\n");
			getch();
			printf("\nCharlie:Distracted? I don't know what you mean ^^ \n");
			getch();
			printf("\nYou:Well,you looked pretty angry when you first arrived.\n");
			getch();
			printf("\nCharlie:Oh, that? Haha, it will be nothing\n");
			getch();
			printf("\nYou:Don't you mean...was?\n");
			getch();
			printf("\nCharlie:...\n");
			getch();
			printf("\nYou:Charlie?\n");
			getch();
			printf("\n*She quickly pulls out the hunting knife out of the bag and stabs you*\n");
			getch();
			printf("\n*You bleed out for a few minutes and eventually die*\n");
			getch();

			has_girlfriend = false;
			has_lamborghini = false;

			game_end(score);
		}

		break;

	case 22:
		if (selection == 1)
		{
			score = score - 10;
			selection == 0;
			index = 22;

			printf("\n *you throw the chair at her and try to run for the exit behind her*\n");
			getch();
			printf("\n*She gets stunned for one second but stabs you in the back while trying to get past her*\n");
			getch();
			printf("\nYou:Oh my go...\n");
			getch();
			printf("\n*She stabs you until you die*\n");
			getch();

			has_girlfriend = false;
			has_lamborghini = false;

			game_end(score);

		}

		else if (selection == 2)
		{
			score = score + 7;
			selection == 0;
			index = 23;
			printf("\n *you hold her back with the chair*\n");
			getch();
			printf("\nYou:Why are you doing this??\n");
			getch();
			printf("\nCharlie:...\n");
			getch();
			printf("\n*Charlie tries to get closer to you*\n");

			getch();
			printf("\nChoices: 1. *hit her with the chair* \n 2. *continue to hold her with the chair*\n");
		}

		break;

	case 23:
		if (selection == 1)
		{
			score = score + 4;
			selection == 0;
			index = 24;

			printf("\n *you hit her with the chair*\n");
			getch();
			printf("\n*She falls to the ground and drops her knife*\n");

			getch();
			printf("\nChoices: 1. *rush to take her knife* \n 2. *run for the exit*\n");
		}

		else if (selection == 2)
		{
			score = score - 5;
			selection == 0;
			index = 23;


			printf("\n *you continue to hold her with the chair*\n");
			getch();
			printf("\nCharlie: Enough of this!\n");
			getch();
			printf("\n*Charlie cuts 3 of your fingers you're using to hold your chair*\n");
			getch();
			printf("\nYou:ARGH!\n");
			getch();
			printf("\n*The chair slips from your left palm*\n");
			getch();
			printf("\nCharlie:You're mine!\n");
			getch();
			printf("\n*Charlie throws you on the ground with a kick*\n");
			getch();
			printf("\n*Charlie stabs you until you die*\n");
			getch();

			has_girlfriend = false;
			has_lamborghini = false;

			game_end(score);

		}

		break;

	case 24:
		if (selection == 1)
		{
			score = score - 6;
			selection == 0;
			index = 24;

			printf("\n *you rush to take her knife*\n");
			getch();
			printf("\n*you take her knife*\n");
			getch();

			printf("\n*She explodes and kills both of you*\n");
			getch();

			has_girlfriend = false;
			has_lamborghini = false;

			game_end(score);

		}

		else if (selection == 2)
		{
			score = score + 15;
			selection == 0;
			index = 24;

			printf("\n*You run for the exit*\n");
			getch();
			printf("\n*You escape and call the police*\n");
			getch();
			printf("\n*The police arrives and arrests Charlie*\n");
			getch();
			printf("\n*You drive your lamborghini in the sunset and enjoy your free coffee*\n");
			getch();

			has_girlfriend = false;
			has_lamborghini = true;

			game_end(score);

		}

		break;

	case 21:
		if (selection == 1)
		{
			score = score - 5;
			selection == 0;
			index = 21;

			printf("\n*you kill the hostage you are holding*\n");
			getch();
			printf("\n*the police shoots both you and Charlie*\n");
			getch();
			printf("\n*both of you get arrested*\n");
			getch();
			printf("\n*you drop the soap in prison*\n");
			getch();

			has_girlfriend = true;
			has_lamborghini = true;

			game_end(score);
		}

		else if (selection == 2)
		{
			score = score + 5;
			selection == 0;
			index = 21;

			printf("\n*you try to shoot a police officer*\n");
			getch();
			printf("*the sniper outside takes advantage of you taking your aim away from the hostage and shoots your hand*\n");
			getch();
			printf("*Charlie's left hand gets shot too and she drops her pistol*");
			getch();
			printf("\n*both of you get arrested*\n");

			has_girlfriend = true;
			has_lamborghini = false;

			game_end(score);
		}

	default:
		printf("\nPlease pick one of the options above.\n");
		getch();

	}
}




